<?php

				echo'<li><a href="Team7.php"><p> HOME </p></a></li>';
				echo'<li><a href="team7_admin.php"><p> ADMIN </p></a></li>';
				echo'<li><a href="7itemsTableInsert.php"><p> REPORT ITEM </p></a></li>';
				echo'<li><a href="team7_logout.php"><p>SIGN IN/OUT</p></a></li>';

?>